# Databricks notebook source
# run the child notebook with the parameter sales or office

# COMMAND ----------

_count = dbutils.notebook.run(
    "01_write_emp_data",
    600,
    {"dept": "office"}
)

# COMMAND ----------

print(f"child notebook count: {_count}")