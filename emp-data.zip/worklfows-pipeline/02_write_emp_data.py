# Databricks notebook source
# dbutils.widgets.text("input_date","")

# COMMAND ----------

# _input_date = dbutils.widgets.get("input_date")
# print(_input_date)

# COMMAND ----------

# spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

# _input_day = spark.sql(f"""
#     SELECT date_format(
#         to_timestamp('{_input_date}', "yyyy-MM-dd'T'HH:mm:ss"),
#         'E'
#     )
# """).collect()[0][0]

# print(_input_day)

# COMMAND ----------

dbutils.fs.head("dbfs:/databricks-datasets/retail-org/company_employees/company_employees.csv")

# COMMAND ----------

dbutils.widgets.text("dept","", "department")

# COMMAND ----------

_dept = dbutils.widgets.get("dept")
print(_dept)




# COMMAND ----------

df = spark.read.csv("dbfs:/databricks-datasets/retail-org/company_employees/company_employees.csv", header=True, inferSchema=True)
df.createOrReplaceTempView('company_employees')

# COMMAND ----------

display(df)

# COMMAND ----------

df_filter = df.where(f"upper(department) = upper('{_dept}') and active_record = 1")
display(df_filter)

# COMMAND ----------

_count = df_filter.count()
print(_count)
if _count > 0:
    df_filter.write.format("delta").option("overwriteSchema", "true").mode("overwrite").saveAsTable(f"workspace_axxx_cicd_dev.acq.dept_{_dept}")
    print(f"Data written to table: {_dept}")
    display(spark.sql(f"select * from workspace_axxx_cicd_dev.acq.dept_{_dept}" ))
else:
    print("No records found for : {_dept}")

# COMMAND ----------

dbutils.notebook.exit(_count)